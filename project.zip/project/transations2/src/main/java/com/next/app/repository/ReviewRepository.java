package com.next.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.next.app.entites.Review;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Integer> {

}

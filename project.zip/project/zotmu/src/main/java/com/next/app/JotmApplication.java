package com.next.app;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.next.app.dto.CustResponse;
import com.next.app.entity.Customer;

@SpringBootApplication
@RestController
@RequestMapping("/cust")
public class JotmApplication {

	public static void main(String[] args) {
		SpringApplication.run(JotmApplication.class, args);
	}
	@Autowired
	private CustomerRepository customerRepository;
	
	@PostMapping
	public ResponseEntity<Customer> saveCustomer(@RequestBody Customer customer){
		
		Customer customerResp =customerRepository.save(customer);
		
		return new ResponseEntity<Customer>(customerResp,HttpStatus.CREATED);
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<Customer>> getAllCustomer(){
		
		return new ResponseEntity<List<Customer>>(customerRepository.findAll(),HttpStatus.OK);
	}
	
	@GetMapping("/filterAll")
	public ResponseEntity<List<Customer>> getFilterAllCustomer(){
		
		return new ResponseEntity<List<Customer>>(customerRepository.findAllCustomersList(),HttpStatus.OK);
	}
	
	@GetMapping("/cresp")
	public ResponseEntity<List<CustResponse>> getCustomerResponse(){
		
		return new ResponseEntity<List<CustResponse>>(customerRepository.findAllCustomers(),HttpStatus.OK);
	}
	
	@GetMapping("/order")
	public ResponseEntity<List<Customer>> getCustomerResponseOrderBy(){
		
		return new ResponseEntity<List<Customer>>(customerRepository.findAllCustomersOrderByList(),HttpStatus.OK);
	}
	
	@GetMapping("/count")
	public ResponseEntity<Integer> getCustomerResponseCount(){
		
		return new ResponseEntity<Integer>(customerRepository.findAllCustomersCount(),HttpStatus.OK);
	}
	
	@GetMapping("/named1")
	public ResponseEntity<Customer> getCustResponse(@RequestParam int id){
		
		return new ResponseEntity<Customer>(customerRepository.findAllCustomersResp(id),HttpStatus.OK);
	}
	

}

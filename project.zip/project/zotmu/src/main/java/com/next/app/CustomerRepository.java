package com.next.app;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.next.app.dto.CustResponse;
import com.next.app.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {//

//	@Query("SELECT new com.next.app.dto.CustResponse(c.name,p.productName) FROM Customer c JOIN c.products p")
	@Query("SELECT new com.next.app.dto.CustResponse(c.name,p.productName) FROM Customer c JOIN c.products p")
	public List<CustResponse> findAllCustomers();
	
	@Query("FROM Customer c WHERE c.id IN (1,4,3)")
	public List<Customer> findAllCustomersList();
	
	@Query("FROM Customer c WHERE c.id IN (1,4,3) ORDER BY c.name")
	public List<Customer> findAllCustomersOrderByList();
	
	@Query("SELECT SUM(c.id) FROM Customer c")
	public int findAllCustomersCount();
	
	//Named Parameters
	@Query("FROM Customer c WHERE c.id=:id")
	public Customer findAllCustomersResp(int id);
	
	
	
}

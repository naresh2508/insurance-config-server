package com.next.app.dto;

import java.io.Serializable;

public class ReviewDto implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int reviewId;
	private String name;
	private String type;
	private String description;
	
	
	public ReviewDto() {
		super();
	}
	
	public ReviewDto(int reviewId, String name, String type, String description) {
		super();
		this.reviewId = reviewId;
		this.name = name;
		this.type = type;
		this.description = description;
	}
	public int getReviewId() {
		return reviewId;
	}
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "ReviewDto [reviewId=" + reviewId + ", name=" + name + ", type=" + type + ", description=" + description
				+"]";
	}
	
	
}

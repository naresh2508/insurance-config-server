package com.next.app.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import com.next.app.entites.Review;

public class ProductDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int productId;
	private String name;
	private double price;
	private String description;
	
	private List<ReviewDto> reviews;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<ReviewDto> getReviews() {
		return reviews;
	}

	public void setReviews(List<ReviewDto> reviews) {
		this.reviews = reviews;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public ProductDto(int productId, String name, double price, String description, List<ReviewDto> reviews) {
		super();
		this.productId = productId;
		this.name = name;
		this.price = price;
		this.description = description;
		this.reviews = reviews;
	}

	public ProductDto(int productId, String name, double price, String description) {
		super();
		this.productId = productId;
		this.name = name;
		this.price = price;
		this.description = description;
	}

	public ProductDto() {
		super();
	}

	@Override
	public String toString() {
		return "ProductDto [productId=" + productId + ", name=" + name + ", price=" + price + ", description="
				+ description + ", reviews=" + reviews + "]";
	}

	
	
}

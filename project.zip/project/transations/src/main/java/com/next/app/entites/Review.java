package com.next.app.entites;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "REVIEW")
public class Review implements Serializable{
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "reviewSeq")
	@SequenceGenerator(name = "reviewSeq",initialValue = 1,allocationSize = 1,sequenceName = "review_seq")
	@Column(name = "review_id")
	private int reviewId;
	private String name;
	private String type;
	private String description;
	
	
	
	
	public Review(int reviewId, String name, String type, String description) {
		super();
		this.reviewId = reviewId;
		this.name = name;
		this.type = type;
		this.description = description;
	}

	public Review() {
		super();
	}
	public int getReviewId() {
		return reviewId;
	}
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public int hashCode() {
		return Objects.hash(description, name, reviewId, type);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Review other = (Review) obj;
		return Objects.equals(description, other.description) && Objects.equals(name, other.name)
				 && reviewId == other.reviewId
				&& Objects.equals(type, other.type);
	}
	@Override
	public String toString() {
		return "Review [reviewId=" + reviewId + ", name=" + name + ", type=" + type + ", description=" + description
				+ "]";
	}

	

	
	
	
}

package com.next.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
@RequestMapping("/basic")
public class TransationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransationsApplication.class, args);
	}
	
	@GetMapping("/get")
	public ResponseEntity<String> getResponse(){
		
		return new ResponseEntity<String>("Welcome to new Start", HttpStatus.OK);
	}

}

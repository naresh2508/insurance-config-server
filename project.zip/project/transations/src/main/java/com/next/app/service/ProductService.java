package com.next.app.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.next.app.dto.ProductDto;
import com.next.app.dto.ReviewDto;
import com.next.app.entites.Product;
import com.next.app.entites.Review;
import com.next.app.repository.ProductRepository;

import jakarta.transaction.Transactional;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Transactional
	public List<Product> getAllProducts() {

		List<ProductDto> dtos = new ArrayList<>();
		List<Product> products = productRepository.findAll();
		System.out.println(products);
//		BeanUtils.copyProperties(products, dtos);
//		dtos=productsBoToDtoMapper(products);
//		System.out.println("dtos::"+dtos);
		return products;

	}
	
//	public List<ProductDto> productsBoToDtoMapper(List<Product> products){
//		
//		List<ProductDto> dtos=new ArrayList<>();
//		for (Product product : products) {
//			
//			ProductDto dto=new ProductDto(product.getProductId(), product.getName(), product.getPrice(), product.getDescription(), reviewBoToDto(product.getReviews()));
//			dtos.add(dto);
//		}
//		return dtos;
//		
//	}
	
//	public List<ReviewDto> reviewBoToDto(List<Review> reviews){
//		List<ReviewDto> dtos=new ArrayList<>();
//		for (Review review : reviews) {
//			Product product=review.getProduct();
//			
//			ReviewDto dto=new ReviewDto(review.getReviewId(), review.getName(), review.getType(), review.getDescription());
//			dtos.add(dto);
//		}
//		return dtos;
//	}

	public Product saveProduct(Product product) {

//		Product product= productDtoToBo(productDto);
		Product productRes= productRepository.save(product);
		ProductDto dto=productBoToDtoMapper(productRes);
		return productRes;
	}

	private ProductDto productBoToDtoMapper(Product product) {

		List<ReviewDto> reviews = new ArrayList<>();
		
		for (Review review : product.getReviews()) {
			ReviewDto bo=new ReviewDto(review.getReviewId(), review.getName(), review.getType(),review.getDescription());
			reviews.add(bo);
		}
		ProductDto dto = new ProductDto(product.getProductId(), product.getName(), product.getPrice(),
				product.getDescription(), reviews);

		return dto;
	}

	private Product productDtoToBo(ProductDto product) {

		List<Review> reviews=new ArrayList<>();
		for (ReviewDto review : product.getReviews()) {
			Review bo=new Review(review.getReviewId(), review.getName(), review.getType(), review.getDescription());
			reviews.add(bo);
		}
		return new Product(product.getProductId(), product.getName(), product.getPrice(), product.getDescription(), reviews);
	}

}

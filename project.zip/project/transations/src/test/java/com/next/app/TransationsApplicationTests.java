package com.next.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransationsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.next.app.entity;

import java.io.Serializable;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "customer")
@AllArgsConstructor
@Data
@NoArgsConstructor
@EqualsAndHashCode
@ToString
public class Customer implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "custRef")
	@SequenceGenerator(name = "custRef",sequenceName = "cust_seq",allocationSize = 1,initialValue = 1)
	private int id;
	private String name;
	private String age;
	private String phone;

//	@OneToMany(targetEntity = Product.class,cascade = CascadeType.ALL)
//	@JoinColumn(name = "pk_id",referencedColumnName = "id")
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "pk_id")
	List<Product> products;
}

package com.next.app;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.next.app.dto.ProductCustomer;
import com.next.app.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
	
	@Query("SELECT new com.next.app.dto.ProductCustomer(c.id,c.name,c.age,c.phone,p.productNo,p.productName,p.price) FROM Customer c JOIN products p")
	public List<ProductCustomer> getAllProductCustomer();

}

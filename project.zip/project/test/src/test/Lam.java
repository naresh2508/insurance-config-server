package test;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class Lam {

	public static void main(String[] args) {
		String roles = "3|USER|ABC|HH|Merchant%20Onboarding%20User(MOU)|OO|PP";
		String existingRoles = "0|2|HH|MIS|USER|ABC";
//		String currentRoles = "1|42|MIS|ADMINISTRATOR|LAMAdmin|RED|QWT";
//
		Set<String> addRoles = new LinkedHashSet<>();
		Set<String> existingRolesSet = null;
		String[] oldRoles = existingRoles.split("\\|");
		String additionalRole = "1";
		existingRolesSet = new LinkedHashSet<>(Arrays.asList(existingRoles.split("\\|")));
		if (additionalRole.equals("1")) {
			System.out.println("Additional Role Required -- NO REPLACE WITH OLD ROLES ");
			String[] newRoles = roles.split("\\|");
			
			Iterator iterator=existingRolesSet.iterator();
			while (iterator.hasNext()) {
				String str=(String)iterator.next();
				try {
					int i=Integer.parseInt(str);
//					System.out.println("Int");
					
				} catch (Exception e) {
					String str1=(String)str;
					addRoles.add(str1);
				}
				
			}
			System.out.println("Before replacement::"+addRoles);
			int replaceCount = Integer.parseInt(newRoles[0]);
			
			for (int j = 1; j <= replaceCount; j++) {
				try {

					if (addRoles.contains(newRoles[j])) {
						addRoles.remove(newRoles[j]);
						addRoles.add(newRoles[j+replaceCount]);
					}
				} catch (Exception e) {
				}
			}

//			for (int i = 0; i < newRoles.length; i++) {
//				if (newRoles[i].equals("API ADMINISTRATOR")) {
//					addRoles.add(newRoles[i]);
//				} else if (newRoles[i].equals("MIS")) {
//					addRoles.add(newRoles[i]);
//				} else if (newRoles[i].equals("ADMINISTRATOR")) {
//					addRoles.add(newRoles[i]);
//				} else if (newRoles[i].equals("USER")) {
//					addRoles.add(newRoles[i]);
//				} else if (newRoles[i].equals("Merchant Onboarding User(MOU)")) {
//					addRoles.add(newRoles[i]);
//				} else if (newRoles[i].equals("LAMAdmin")) {
//					addRoles.add(newRoles[i]);
//				} else {
//					;
//				}
//			}

		}

		System.out.println("After replacement::"+addRoles);
		String allRoles = addRoles.size() + "|" + String.join("|", addRoles);
		System.out.println("Updated LAM roles : " + allRoles);
//		System.out.println(role[0]);
//		System.out.println(role[1]);
	}

}

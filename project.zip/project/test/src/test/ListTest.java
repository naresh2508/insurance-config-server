package test;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class ListTest {

	public static void main(String[] args) {

		
		List<Integer> integers=Arrays.asList(22,39,88,77,99,3,5,88,91,7);
		
		List<Integer> integers2=integers.stream().sorted((o1, o2) -> o2.compareTo(o1)).toList();
		
		System.out.println(integers2);
	}

}

package test;

public class NeoTest {

	public static void main(String[] args) {

		//Find the factorial of a number using recurssion
		
		//n! n*n-1...
		int fact=1;
		System.out.println(factorial(4));
		
	}
	
	public static int factorial(int n) {
		int fact=1;
		if (n>=1) {
			
			
			fact= n*factorial(n-1);
			n--;
		}
		return fact;
	}
	
	//// select * from emp where sal=(select max(sal) from emp);
	//  

}

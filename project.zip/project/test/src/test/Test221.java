package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Test221 {

	public static void main(String[] args) {

		System.out.println("Hello world");
		
		//[1,2,5,6,7,12,15,1,34,57,1,61]
		
//		List<Integer> integers=Arrays.asList(1,2,5,6,7,12,15,1,34,57,1,61);
		
		Integer[] values=new Integer[] {1,2,5,6,7,12,15,1,34,57,1,61};
		System.out.println(values.length);
		
		for (int i = 0; i < values.length-1; i++) {
			
			for (int j = 0; j < values.length-1; j++) {
				if(values[j]==1) {
					int temp=values[j+1];
					values[j+1]=values[j];
					values[j]=temp;
				}
			}
			
			
		}
		
		for(int i1:values) {
			System.out.println(i1);
		}
		
		
	}

}

package test;

import java.util.HashMap;
import java.util.Map;

public class Test {

	public static void main(String[] args) {

		Map<String, Boolean> map=new HashMap<>();
		String s="Arva Naresh";
		
		for(int i=0;i<s.length();i++) {
//			if(s.charAt(i)) {
//				
//			}
		}
	}

}

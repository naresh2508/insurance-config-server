package test;


public class Test2 {

	
	static final int NO_OF_CHARS = 256;
    static char count[] = new char[NO_OF_CHARS];
	
	public static void main(String[] args) {

		String str12 = "geeksforgeeks";
	
//		find the first unique char from giving string.
//		Input swiss
//		output w
//	
		String str="swiss";
		//finding for index
		int index=0;
		char firstChar=' ';
		
		if(str.length()>0) {
			char[] cs=str.toCharArray();
			for(char c:str.toCharArray()) {
//				System.out.println(c+"-->str.charAt(c)::"+String.valueOf(str.indexOf(c)==str.lastIndexOf(c)));
				if(str.indexOf(c)==str.lastIndexOf(c)) {
					System.out.println("First occurence of charater::"+c);
					firstChar=c;
					break;
				}else {
					index=+1;
				}
			}
			if(index==str.length()-1) {
				System.out.println("All characters are reapting");
			}
			
		}else {
			System.out.println("Empty String");
		}
		
		for (int i = 0; i < str.length(); i++) {
		      if (str.indexOf(str.charAt(i), str.indexOf(str.charAt(i)) + 1) == -1) {
		        System.out.println("First non-repeating character is "+ str.charAt(i));
		        break;
		      }
		    }
		String string="repeatinge";
		System.out.println(string.indexOf('t', 2));
		
//		getCharCountArray(string);
		System.out.println("============================================");
		System.out.println(count[str.charAt(5)]++);
	
	}
	
	static void getCharCountArray(String str)
    {
        for (int i = 0; i < str.length(); i++)
            count[str.charAt(i)]++;
    }

}

package test;

import java.util.HashMap;
import java.util.stream.Collectors;

public class HashTest {

	public static void main(String[] args) {

		
		HashMap<String, Integer> hashMap=new HashMap<>();
		
		hashMap.put("ONE", 1);
		hashMap.put("SIX", 6);
		hashMap.put("NINE", 9);
		hashMap.put("TWO", 2);
		hashMap.put("EIGHT", 8);
		hashMap.put("SEVEN", 7);
		
//		hashMap.entrySet().stream().map((h1,h2)->h1.getKey().compareTo(h2.getKey())).collect(Collectors.toMap(, Integer.class))
		
		
		
	}

}

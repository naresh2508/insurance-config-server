package test;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class Test30 {

	public static void main(String[] args) {

		
		List<Emp> integers=Arrays.asList(
				new Emp(1, "Naresh"),
				new Emp(2, "Kiran"),
				new Emp(1, "Naresh"),
				new Emp(3, "Varun")
				);
	
		List<Emp> int2=integers.stream().distinct().toList();
		
		System.out.println(int2);
		
	}

}

class Emp{
	private int empNo;
	private String empName;
	public Emp(int empNo, String empName) {
		super();
		this.empNo = empNo;
		this.empName = empName;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	
	
	@Override
	public int hashCode() {
		return Objects.hash(empName, empNo);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Emp other = (Emp) obj;
		return Objects.equals(empName, other.empName) && empNo == other.empNo;
	}
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empName=" + empName + "]";
	}
	
	
	
}

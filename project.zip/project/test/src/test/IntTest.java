package test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class IntTest {

	public static void main(String[] args) {

		List<Integer> integers=Arrays.asList(40,70,80,50,90,20);
		Integer second=integers.stream().sorted((i1,i2)->i2.compareTo(i1)).skip(1).findFirst().get();
		System.out.println("Desc:"+second);
	}

}

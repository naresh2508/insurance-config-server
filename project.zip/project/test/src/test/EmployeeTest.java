package test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeTest {

	public static void main(String[] args) {
		
		List<Employee> employees=Arrays.asList(
				new Employee(1, "Naresh", 45000, 28),
				new Employee(2, "Varun", 50000, 20),
				new Employee(3, "Naresh", 70000, 15),
				new Employee(4, "Naresh", 80000, 30),
				new Employee(5, "Naresh", 90000, 29),
				new Employee(6, "Naresh", 85000, 30)
				);
		List<Employee> list=null;
		if(!employees.isEmpty()) {
		list=employees.stream().map(e1->{
			int percentage=e1.getAttendenceDays()*100/30;
			e1.setPercentage(percentage);
			if(percentage<=75 && percentage>50) {
				e1.setSalary(e1.getSalary()*75/100);
				return e1;
			}else if(percentage<=50) {
				e1.setSalary(e1.getSalary()*50/100);
				return e1;
			}else{
				return e1;
			}
			
		}).collect(Collectors.toList());
		}
		
		System.out.println(list);
	}

}



class Employee{
	
	private int empNo;
	private String ename;
	private long salary;
	private int attendenceDays;
	private int percentage;
	
	public Employee(int empNo, String ename, long salary, int attendenceDays) {
		super();
		this.empNo = empNo;
		this.ename = ename;
		this.salary = salary;
		this.attendenceDays = attendenceDays;
	}

	
	public int getPercentage() {
		return percentage;
	}


	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}


	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public int getAttendenceDays() {
		return attendenceDays;
	}

	public void setAttendenceDays(int attendenceDays) {
		this.attendenceDays = attendenceDays;
	}


	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", ename=" + ename + ", salary=" + salary + ", attendenceDays="
				+ attendenceDays + ", percentage=" + percentage + "]";
	}


	
	
	
}

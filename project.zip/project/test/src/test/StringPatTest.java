package test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class StringPatTest {

	public static void main(String[] args) {

		String str1 = "the feature predictions are expected";
//		StringBuffer buffer =new StringBuffer(str1);
//		System.out.println(buffer.reverse().toString());

		System.out.println("=====================================================");
		char[] cs = str1.toCharArray();
		int startIndex = 0;
		int endIndex = str1.length() - 1;
		while (startIndex <= endIndex) {
			char temp = ' ';
			temp = cs[startIndex];
			cs[startIndex] = cs[endIndex];
			cs[endIndex] = temp;
			startIndex++;
			endIndex--;
		}
		String string = new String(cs);
		System.out.println(string);
		System.out.println("=============================================");
		
		//find out first non repeating char
		String str2 = "Arva Naresh #CGO# Video Interview Confirmation";
		int count =0;
		for(int i=0;i<str2.length();i++) {
			
			if(str2.indexOf(str2.charAt(i))==str2.lastIndexOf(str2.charAt(i))) {
				System.out.println("First non reapeting char::"+str2.charAt(i));
				count++;
//				break;
			}
			if(count==2) break;
		}
		System.out.println("=============================================");
		String str3 = "The interview will be conducted over Teams Meeting.";
		char[] cs2=str3.toCharArray();
		
		Map<Character, Integer> map=new HashMap<>();
		for(int i=0;i<str3.length();i++) {
			int count1=0;
			if(map.containsKey(cs2[i])) {
				count1=map.get(cs2[i]);
				map.put(cs2[i], ++count1);
			}else {
				map.put(cs2[i], ++count1);
			}
		}
		System.out.println(map);
		System.out.println("=============================================");
		String str4 = "KASAK";

		char[] cs3=str4.toCharArray();
		int startIndex1=0;
		int endIndex1=cs3.length-1;
		for (int i = 0; i < cs3.length; i++) {
			while (startIndex1<=endIndex1) {
				char temp=cs3[endIndex1];
				cs3[endIndex1]=cs3[startIndex1];
				cs3[startIndex1]=temp;
				startIndex1++;
				endIndex1--;
			}
		}
		String out=String.valueOf(cs3);
		System.out.println(out);
		if(str4.equals(out) )
			System.out.println("Both are same"); 
		else 
			System.out.println("Not same");  
		System.out.println("=============================================");
		String str5 = "KASAK";
		char[] cs4=str5.toCharArray();
		Arrays.sort(cs4);
		System.out.println(new String(cs4));
		
		
		
	}

}

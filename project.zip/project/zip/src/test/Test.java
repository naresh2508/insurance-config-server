package test;

import java.util.Arrays;
import java.util.List;

public class Test {

	public static void main(String[] args) {

		List<Employee> employees=Arrays.asList(
				
				new Employee(1, 25000, "Naresh"),
				new Employee(1, 10000, "Arun"),
				new Employee(1, 30000, "Kiran"),
				new Employee(1, 35000, "Tarun"),
				new Employee(1, 5000, "Raj")
				);
		
		for(int i=0;i<employees.size()-1;i++){

			if(!(employees.get(i).getSalary()>employees.get(i+1).getSalary())) {
				Employee temp=employees.get(i+1);
				employees.set(i, temp);
				employees.set(i+1, employees.get(i));
				
			}else if(employees.get(i).getSalary()<employees.get(i+1).getSalary()) {
				;
			}

		}
		
		System.out.println(employees);
		
	}

}

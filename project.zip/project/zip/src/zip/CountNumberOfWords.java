package zip;


public class CountNumberOfWords {

	public static void main(String[] args) {
		// Way1====================
		
		String str = "My Name Is Arva Naresh is name my a sir order of thing Thing OF MY NARESH";

		String[] strs = str.split(" ");
		System.out.println(strs.length);
//		==================================================================
		// Way2====================
		int count=1;
		char[] chars=str.toCharArray();
		for (int i = 0; i < chars.length; i++) {
			if(chars[i]==' '&&chars[i+1]!=' ') {
				count++;
			}
		}
		System.out.println("Count::"+count);
	}
}

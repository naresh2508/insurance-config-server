package zip;

import java.util.HashMap;
import java.util.Map;

public class CountNumberOfOccurrencesCharacterWithoutLoop {

	public static void main(String[] args) {
		
		String str = "My Name Is Arva Naresh is name my a sir order of thing Thing OF MY NARESH";

		char[] chars=str.toCharArray();
		Map<Character, Integer> count=new HashMap<>();
		count=charCount(str,count);
		System.out.println(count);
		
	}
	
	public static Map<Character, Integer> charCount(String str, Map<Character, Integer> map) {
//My Name Is Arva Naresh is name my a sir order of thing Thing OF MY NARESH
		int index=0;
		int count=1;
		if(str.length()>1) {
			if(map.containsKey(str.charAt(index))) {
				Integer countNo=(Integer)map.get(str.charAt(index));
				Character ch=str.charAt(index);
				map.put(ch, ++countNo);
			}
			else
			{
				map.put(str.charAt(index), count);
			}
//			map.put(str, null)
			index++;
			charCount(str.substring(index, str.length()), map);
		}
		return map;
	}
}

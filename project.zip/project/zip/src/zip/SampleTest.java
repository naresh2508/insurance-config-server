package zip;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class SampleTest {

	public static void main(String[] args) {

		String str="My Name Is Arva Naresh";
//		========================================================
		long counts=str.chars().filter(c -> {
//			System.out.println((char)c);
			if((char)c>'Z')
				return true;
			return false;
			
		}).count();
//		System.out.println(counts);
//	====================================================================	
		
		str.chars()
		.mapToObj(c->(char)c)
		.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
		.entrySet().stream().filter(e->e.getValue()>1)
		.forEach(entry->System.out.println("Character::"+entry.getKey()+"  "+entry.getValue()));;
//	=========================================================================	
		
		char[] chars=str.toCharArray();
		Map<Character, Integer> map=new HashMap<>();
		
		
		for (int i = 0; i < chars.length; i++) {
			
			if(map.containsKey(chars[i])) {
				Integer count=map.get(chars[i])+1;
				map.put(chars[i], count);
			}else {
				map.put(chars[i], 1);
			}
		}
		System.out.println(map);
	}

}

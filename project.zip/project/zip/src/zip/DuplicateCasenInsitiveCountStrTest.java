package zip;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
public class DuplicateCasenInsitiveCountStrTest {

	public static void main(String[] args) {
		// public static boolean isWhitespace(char ch)
		String str = "My Name Is Arva Naresh is name my a sir order of thing Thing OF MY NARESH";

		String[] strs = str.split(" ");
		System.out.println(strs.toString());
		Map<String, Integer> map = new HashMap<>();

		for (int i = 0; i < strs.length; i++) {
			boolean keyMatch = false;
			int count = 0;
			String key="";
			Set<Entry<String, Integer>> keys = map.entrySet();
			if (map.size() > 0) {
				for (Iterator iterator = keys.iterator(); iterator.hasNext();) {
					Entry<String, Integer> entry = (Entry<String, Integer>) iterator.next();
					if (entry.getKey().equalsIgnoreCase(strs[i])) {
						count = entry.getValue();
						keyMatch = true;
						key= entry.getKey();
						break;
					}
				}
			}

			if (keyMatch) {
//				Integer integer = map.get(strs[i]);
				map.put(key, ++count);
			} else {
				map.put(strs[i], 1);
			}
		}
		System.out.println(map);
	}
}

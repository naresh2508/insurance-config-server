package zip;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class DuplicateCountStrTest2 {

	public static void main(String[] args) {
		//public static boolean isWhitespace(char ch) 
		String str="My Name Is Arva Naresh is name my a sir order of thing Thing OF MY NARESH";

		Map<String, Integer> map=new HashMap<>();
		List<String> list=new ArrayList<>();
		char[] cs=str.toCharArray();
		StringBuffer str12=new StringBuffer();
		for (int i = 0; i < cs.length; i++) {
			
			if(Character.isWhitespace(cs[i])) {
				list.add(str12.toString());
				str12=new StringBuffer();
			}else {
				str12.append(String.valueOf(cs[i]));
			}
		}
		System.out.println(list);
		
	}

}

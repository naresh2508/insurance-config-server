package zip;

import java.util.HashMap;
import java.util.Map;
public class DuplicateCasensitiveCountStrTest {

	public static void main(String[] args) {
		//public static boolean isWhitespace(char ch) 
		String str="My Name Is Arva Naresh is name my a sir order of thing Thing OF MY NARESH";

		String[] strs=str.split(" ");
		System.out.println(strs.toString());
		Map<String, Integer> map=new HashMap<>();
		
		for (int i = 0; i < strs.length; i++) {
			
			if(map.containsKey(strs[i])) {
				Integer integer=map.get(strs[i]);
				map.put(strs[i], integer++);
			}else {
				map.put(strs[i], 1);
			}
		}
		System.out.println(map);
	}
}

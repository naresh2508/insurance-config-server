package zip;

public class RemoveWhiteSpacesStringTest {

	public static void main(String[] args) {

		String str = "My Name Is Arva Naresh is name my a sir order of thing Thing OF MY NARESH";
//		System.out.println(str.replaceAll(" ", ""));
		
		
	}

}

package zip;

public class ReverseOfStringTest {

	public static void main(String[] args) {

		String str = "Java is java again java again";
System.out.println(str.substring(1));
		String revStr = reverseString(str);
		System.out.println(revStr);
	}

	private static String reverseString(String str) {

		String s = "";
		if (str.length() > 1)
			return s + str.charAt(str.length() - 1) + reverseString(str.substring(0, str.length() - 1));
		else
			return String.valueOf(str.charAt(0));
	}
}

package com.stream.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class S1_AllMatchTest {

	public static void main(String[] args) {

		List<EmployeeInfo> empInfos=new ArrayList<>();
		empInfos.add(new EmployeeInfo(1, "kiran@gmail.com", "&&**&&**", "Kiran", 45000.0,"DEV"));
		empInfos.add(new EmployeeInfo(2, "varun@gmail.com", "&&&**&gdg&**", "varun", 55000.0,"DEV"));
		empInfos.add(new EmployeeInfo(3, "tarun@gmail.com", "&&**&&**", "tarun", 60000.0,"TEST"));
		empInfos.add(new EmployeeInfo(4, "ranga@gmail.com", "&dgd&**&gd&**", "ranga", 48000.0,"TEST"));
		empInfos.add(new EmployeeInfo(5, "naresh@gmail.com", "&&**&&**", "naresh", 65000.0,"TEST"));
		
		long count=empInfos.stream().count();
		System.out.println("count::"+count);
		List<EmployeeInfo> infos=empInfos.stream().filter(e->e.getSalary()>48000f).collect(Collectors.toList());
	
		infos.forEach(System.out::println);
		System.out.println("================================================================");
//		List<EmployeeInfo> infos2=empInfos.stream().map(e->{
//			e.setSalary(e.getSalary()*2); 
//			return e;})
//			.collect(Collectors.toList());
//		infos2.forEach(System.out::println);
		
		System.out.println("================================================================");
		Stream<EmployeeInfo> emps2 = empInfos.stream()
				.sorted((p1, p2) -> p1.getSalary().compareTo(p2.getSalary()));
			emps2.collect(Collectors.toList()).forEach(System.out::println);
			System.out.println("================================================================");
		List<EmployeeInfo> list=empInfos.stream().sorted((e1,e2)->e1.getSalary().compareTo(e2.getSalary())).collect(Collectors.toList());
		list.forEach(System.out::println);
		
		System.out.println("================================================================");

		List<EmployeeInfo> listDesc = empInfos.stream().sorted((e1, e2) -> e2.getSalary().compareTo(e1.getSalary()))
				.skip(1).collect(Collectors.toList());
		listDesc.forEach(System.out::println);
		System.out.println("================================================================");

		EmployeeInfo listDesc2 = empInfos.stream().sorted((e1, e2) -> e2.getSalary().compareTo(e1.getSalary()))
				.skip(1).findFirst().get();
		System.out.println(listDesc2);
		System.out.println("================================================================");

		Double sum = empInfos.stream().filter(e->e.getPassword().equalsIgnoreCase("&&**&&**"))
				.map(e1->e1.getSalary()).mapToDouble(e->e).reduce((a,b)->a+b).getAsDouble(); 
		System.out.println(sum);
		
		
	}

}
class EmployeeInfo{
	private int id;
	private String email;
	private String password;
	private String userName;
	private Double salary;
	private String department;
	public EmployeeInfo(int id, String email, String password, String userName, Double salary, String department) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
		this.userName = userName;
		this.salary = salary;
		this.department = department;
	}
	protected int getId() {
		return id;
	}
	protected void setId(int id) {
		this.id = id;
	}
	protected String getEmail() {
		return email;
	}
	protected void setEmail(String email) {
		this.email = email;
	}
	protected String getPassword() {
		return password;
	}
	protected void setPassword(String password) {
		this.password = password;
	}
	protected String getUserName() {
		return userName;
	}
	protected void setUserName(String userName) {
		this.userName = userName;
	}
	protected Double getSalary() {
		return salary;
	}
	protected void setSalary(Double f) {
		this.salary = f;
	}
	protected String getDepartment() {
		return department;
	}
	protected void setDepartment(String department) {
		this.department = department;
	}

	@Override
	public int hashCode() {
		return Objects.hash(department, email, id, password, salary, userName);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeInfo other = (EmployeeInfo) obj;
		return Objects.equals(department, other.department) && Objects.equals(email, other.email) && id == other.id
				&& Objects.equals(password, other.password) && Objects.equals(salary, other.salary)
				&& Objects.equals(userName, other.userName);
	}
	@Override
	public String toString() {
		return "EmployeeInfo [id=" + id + ", email=" + email + ", password=" + password + ", userName=" + userName
				+ ", salary=" + salary + ", department=" + department + "]";
	}
	
	
	
}
	
package com.stream.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

public class ParallelStreamExample {

	public static void main(String[] args) {

		long start=0;
		long end=0;
		
//		start=System.currentTimeMillis();
//		IntStream.range(1, 1000).forEach(System.out::println);
//		end=System.currentTimeMillis();
//		System.out.println("Sequencial Processing ::"+(end-start));
//		System.out.println("===============================================================");
//		start=System.currentTimeMillis();
//		IntStream.range(1, 1000).parallel().forEach(System.out::println);
//		end=System.currentTimeMillis();
//		System.out.println("Parallel Processing ::"+(end-start));
//	
		
//		IntStream.range(1, 1000).forEach(x->{
//			System.out.println("Thread :"+Thread.currentThread().getName()+" ::"+x);
//		});
//
//		IntStream.range(1, 1000).parallel().forEach(x->{
//			System.out.println("Thread :"+Thread.currentThread().getName()+" ::"+x);
//		});
		
//		List<EmployeeParallel> employeeParallels=EmployeeDataBase.getAllEmployees();
//		start=System.currentTimeMillis();
//		double sumofSalary=employeeParallels.stream().map(e1->e1.getSalary()).mapToDouble(e->e).reduce((a,b)->a+b).getAsDouble();
//		System.out.println(sumofSalary);
//		end=System.currentTimeMillis();
//		System.out.println("Sequencial Processing ::"+(end-start));
//		System.out.println("=============================================================");
//		start=System.currentTimeMillis();
//		double sumofSalaryParallel=employeeParallels.parallelStream().map(EmployeeParallel::getSalary).mapToDouble(e->e).reduce((a,b)->a+b).getAsDouble();
//		System.out.println(sumofSalaryParallel);
//		end=System.currentTimeMillis();
//		System.out.println("Parallel Processing ::"+(end-start));
	
		
		List<EmployeeParallel> employeeParallels=EmployeeDataBase.getAllEmployees();
		start=System.currentTimeMillis();
		double sumofSalary=employeeParallels.stream().map(e1->e1.getSalary()).mapToDouble(e->e).average().getAsDouble();
		System.out.println(sumofSalary);
		end=System.currentTimeMillis();
		System.out.println("Sequencial Processing ::"+(end-start));
		System.out.println("=============================================================");
		start=System.currentTimeMillis();
		double sumofSalaryParallel=employeeParallels.parallelStream().map(EmployeeParallel::getSalary).mapToDouble(e->e).average().getAsDouble();
		System.out.println(sumofSalaryParallel);
		end=System.currentTimeMillis();
		System.out.println("Parallel Processing ::"+(end-start));
		
	}

}

class EmployeeParallel{
	
	private int id;
	private String name;
	private double salary;
	public EmployeeParallel(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	protected int getId() {
		return id;
	}
	protected void setId(int id) {
		this.id = id;
	}
	protected String getName() {
		return name;
	}
	protected void setName(String name) {
		this.name = name;
	}
	protected double getSalary() {
		return salary;
	}
	protected void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "EmployeeParallel [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	
	
	
}

class EmployeeDataBase{
	
	public static List<EmployeeParallel> getAllEmployees(){
		
		List<EmployeeParallel> employeeLists=new ArrayList<>();
		for (int i = 0; i < 1000; i++) {
			employeeLists.add(new EmployeeParallel(i, "Employee-"+1, Double.valueOf(new Random().nextInt(1000*100))));
		}
		
		return employeeLists;
	}
}

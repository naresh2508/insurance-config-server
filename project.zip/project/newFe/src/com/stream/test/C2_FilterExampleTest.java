package com.stream.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class C2_FilterExampleTest {

	public static void main(String[] args) {

		List<Product> list=new ArrayList<>();
		for(Product product:getProducts()) {
			if(product.getPrice()>25000f) {
				list.add(product);
			}
		}
		
		for (Product product : list) {
			System.out.println(product);
		}
	System.out.println("-------------------------------------------");	
		//Using Stream API
		List<Product>  products=getProducts().stream()
				.filter(product->product.getPrice()>25000f)
				.collect(Collectors.toList());
		
		products.forEach(System.out::println);
		System.out.println("-------------------------------------------");	
		List<Product> list2=getProducts().stream().sorted((p1,p2)->{
			if (p1.getPrice() > p2.getPrice()) {
				return 1;
			} else if (p1.getPrice() < p2.getPrice()) {
				return -1;
			} else {
				return 0;
			}
			}).collect(Collectors.toList());
		
		list2.forEach(System.out::println);
		System.out.println("-------------------------------------------");	
		List<Product> list3=getProducts().stream().sorted(Comparator.comparing(Product::getPrice)).collect(Collectors.toList());
		
		list3.forEach(System.out::println);
		
	}
	
	private static List<Product> getProducts(){
		List<Product> list=new ArrayList<>();
		list.add(new Product(1, "HP", 25000f));
		list.add(new Product(2, "DELL", 30000f));
		list.add(new Product(6, "SONY", 45000f));
		list.add(new Product(3, "ACER", 55000f));
		list.add(new Product(4, "LENOVO", 32000f));
		list.add(new Product(5, "APPLE", 65000f));
		return list;
	}

}

class Product{
	
	private int id;
	private String name;
	private float price;
	public Product(int id, String name, float price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
}

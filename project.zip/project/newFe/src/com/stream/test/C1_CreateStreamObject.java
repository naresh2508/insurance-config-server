package com.stream.test;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

public class C1_CreateStreamObject {
	public static void main(String[] args) {

		//Creating the Stream
		Stream<String> stream=Stream.of("a","b","c");
		stream.forEach(System.out::println);
		
		//Creating the Steam form the Sources
		Collection<String> collection=Arrays.asList("JAVA","J2EE","Spring","Hibernate");
		Stream<String> stream2=collection.stream();
		stream2.forEach(System.out::println);
		
		//Creating the Steam form the Sources of List
		List<String> list = Arrays.asList("JAVA", "J2EE", "Spring", "Hibernate");
		Stream<String> stream3 = list.stream();
		stream3.forEach(System.out::println);
		
		// Creating the Steam form the Set
		Set<String> set = new HashSet<>(list);
		Stream<String> stream4 = set.stream();
		stream4.forEach(System.out::println);
		
		String[] strArray= {"a","b","c","d"};
		Stream<String> stream5=Arrays.stream(strArray);
		stream5.forEach(System.out::println);
		
		
		
	}
}

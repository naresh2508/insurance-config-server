package com.stream.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class C3_StreamListSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> list = new ArrayList<>();
		list.add("BANANA");
		list.add("FGJKAA");
		list.add("TREYU");
		list.add("WTSFG");
		list.add("PIOUPOU");
		list.add("FRUIT");

		List<String> list2 = list.stream().sorted(Comparator.naturalOrder()).collect(Collectors.toList());
		System.out.println(list2);

		List<String> list3=list.stream().sorted((o1,o2)->o1.compareTo(o2)).collect(Collectors.toList());
		System.out.println(list3);
		
		List<String> list4=list.stream().sorted().collect(Collectors.toList());
		System.out.println(list4);
		
		//desc
		List<String> sortedList2 = list.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println(sortedList2);

		List<String> sortedList3=list.stream().sorted((o1,o2)->o2.compareTo(o1)).collect(Collectors.toList());
		System.out.println(sortedList3);
		
		//
		List<Employee> employees=new ArrayList<>();
		employees.add(new Employee(10, "Ramesh", 30,400000));
		employees.add(new Employee(20, "kiran", 29,300000));
		employees.add(new Employee(30, "tarun", 30,100000));
		employees.add(new Employee(40, "varun", 20,900000));
		employees.add(new Employee(50, "Karan", 29,200000));
		
		List<Employee> employees2=employees.stream().sorted(new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return (int) (o1.getSalary()-o2.getSalary());
			}
			
		}).collect(Collectors.toList());
		System.out.println(employees2);
		
		List<Employee> employees3 = employees.stream()
				.sorted((o1, o2) -> (int) (o1.getSalary() - o2.getSalary()))
				.collect(Collectors.toList());
		System.out.println(employees3);
		List<Employee> employees4 = employees.stream()
				.sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
				.collect(Collectors.toList());
		System.out.println(employees4);
		
		List<Employee> employees5 = employees.stream()
				.sorted(Comparator.comparingDouble(Employee::getDeptNo))
				.collect(Collectors.toList());
		System.out.println(employees5);
		

		List<Employee> employees6 = employees.stream()
				.sorted(Comparator.comparingDouble(Employee::getDeptNo).reversed())
				.collect(Collectors.toList());
		System.out.println(employees6);
		
		List<Employee> employees7 = employees.stream()
				.sorted(Comparator.comparing(Employee::getName))
				.collect(Collectors.toList());
		System.out.println(employees7);
		
		List<Employee> employees8 = employees.stream()
				.sorted(Comparator.comparing(Employee::getName).reversed())
				.collect(Collectors.toList());
		System.out.println(employees8);
		
	}

}


class Employee{
	private int no;
	private String name;
	private int deptNo;
	private double salary;
	
	
	
	public Employee(int no, String name, int deptNo, double salary) {
		super();
		this.no = no;
		this.name = name;
		this.deptNo = deptNo;
		this.salary = salary;
	}
	protected int getNo() {
		return no;
	}
	protected void setNo(int no) {
		this.no = no;
	}
	protected String getName() {
		return name;
	}
	protected void setName(String name) {
		this.name = name;
	}
	protected int getDeptNo() {
		return deptNo;
	}
	protected void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}
	protected double getSalary() {
		return salary;
	}
	protected void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [no=" + no + ", name=" + name + ", deptNo=" + deptNo + ", salary=" + salary + "]";
	}
	
	
}

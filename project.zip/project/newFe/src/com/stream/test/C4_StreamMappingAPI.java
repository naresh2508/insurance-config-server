package com.stream.test;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class C4_StreamMappingAPI {

	public static void main(String[] args) {

		List<User> list=new ArrayList<>();
		list.add(new User(2, "nat@jyfyj.com", "####", "Karan"));
		list.add(new User(1, "yryx@jyfyj.com", "^^^^", "Varun"));
		list.add(new User(3, "rqraz@jyfyj.com", "@@@", "Eava"));
		list.add(new User(5, "okoj@jyfyj.com", "$$$", "Yogesh"));
		list.add(new User(4, "tsrs@jyfyj.com", "----", "Surender"));
		
		//Convert the User bo to DTo object
		List<UserDTO> userDTOs=new ArrayList<>();
		for (User user : list) {
			userDTOs.add(new UserDTO(user.getId(), user.getEmail(), user.getUserName()));
		}
		for (UserDTO userDTO : userDTOs) {
			System.out.println(userDTO);
		}
		
		//using Stream().map()
		list.stream().map(new Function<User, UserDTO>() {

			@Override
			public UserDTO apply(User user) {
				return new UserDTO(user.getId(), user.getEmail(), user.getUserName());
			}
			
		}).collect(Collectors.toList());
		
		list.stream().map(user->new UserDTO(user.getId(), user.getEmail(), user.getUserName()))
		.collect(Collectors.toList());
		
		list.stream().map(user->new UserDTO(user.getId(), user.getEmail(), user.getUserName()))
		.forEach(userDto->{System.out.println(userDto);});
	}

}

class UserDTO{
	private int id;
	private String email;
	private String userName;
	public UserDTO(int id, String email, String userName) {
		super();
		this.id = id;
		this.email = email;
		this.userName = userName;
	}
	protected int getId() {
		return id;
	}
	protected void setId(int id) {
		this.id = id;
	}
	protected String getEmail() {
		return email;
	}
	protected void setEmail(String email) {
		this.email = email;
	}
	protected String getUserName() {
		return userName;
	}
	protected void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "UserDTO [id=" + id + ", email=" + email + ", userName=" + userName + "]";
	}
	
}
class User{
	private int id;
	private String email;
	private String password;
	private String userName;
	public User(int id, String email, String password, String userName) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
		this.userName = userName;
	}
	protected int getId() {
		return id;
	}
	protected void setId(int id) {
		this.id = id;
	}
	protected String getEmail() {
		return email;
	}
	protected void setEmail(String email) {
		this.email = email;
	}
	protected String getPassword() {
		return password;
	}
	protected void setPassword(String password) {
		this.password = password;
	}
	protected String getUserName() {
		return userName;
	}
	protected void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", email=" + email + ", password=" + password + ", userName=" + userName + "]";
	}
	
	
}

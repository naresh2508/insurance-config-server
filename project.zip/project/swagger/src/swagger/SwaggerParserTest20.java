package swagger;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import io.swagger.models.Swagger;
import io.swagger.parser.OpenAPIParser;
import io.swagger.parser.Swagger20Parser;
import io.swagger.parser.SwaggerParser;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.Paths;
import io.swagger.v3.oas.models.SpecVersion;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.servers.Server;
import io.swagger.v3.parser.OpenAPIV3Parser;
import io.swagger.v3.parser.core.models.ParseOptions;
import io.swagger.v3.parser.core.models.SwaggerParseResult;

public class SwaggerParserTest20 {

	public static void main(String[] args) throws IOException {
//		SwaggerParseResult result = new OpenAPIParser().readLocation("D:\\eCollection YAML.yaml", null, null);
//		boolean isOpenapi=result.isOpenapi31();
//		System.out.println(isOpenapi);
//		OpenAPI openAPI = result.getOpenAPI();
//		System.out.println(openAPI.getInfo());
		
		//OpenAPI 3.0
//		OpenAPI openAPI = new OpenAPIV3Parser().read("https://petstore3.swagger.io/api/v3/openapi.json");
//		 AuthorizationValue apiKey = new AuthorizationValue("api_key", "special-key", "header");
//		  OpenAPI openAPI = new OpenAPIV3Parser().readWithInfo("https://petstore3.swagger.io/api/v3/openapi.json",Arrays.asList(mySpecialHeader, apiKey);
		
//		OpenAPI 3.0
		ParseOptions parseOptions = new ParseOptions();
		parseOptions.setResolve(true); 
		final OpenAPI openAPI = new OpenAPIV3Parser().read("D:\\GAS.yaml", null, parseOptions);
//		
//		
		Paths paths=openAPI.getPaths();
		PathItem item=paths.get("/send-alert");
		System.out.println(item.getPost().getRequestBody().toString()+" dgd");
		Set<Entry<String, MediaType>> entries=item.getPost().getRequestBody().getContent().entrySet();
		Iterator<Entry<String, MediaType>> iterator=entries.iterator();
		Entry<String, MediaType> entry=iterator.next();
		
		System.out.println(entry.getKey());
		System.out.println(openAPI.getPaths().keySet());
		
		
		Map<String, Schema> map=openAPI.getComponents().getSchemas();
		
		System.out.println(map.keySet()+"HHH");
		
			Schema<?> schema=map.get("request");
			
			System.out.println(schema.getType());
			Map<String, Schema> map2=schema.getProperties();
			System.out.println(map2.keySet());
//			Schema schema2=map2.get("gas");
//			System.out.println(schema2.getType());
		
		
		
//		Swagger swagger = new SwaggerParser().read("D:\\GAS.yaml");
//		
//		System.out.println(swagger.getInfo());
//		
	}

}

package swagger;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

import io.swagger.models.Response;
import io.swagger.models.Swagger;
import io.swagger.models.properties.Property;
import io.swagger.parser.OpenAPIParser;
import io.swagger.parser.Swagger20Parser;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.Paths;
import io.swagger.v3.oas.models.SpecVersion;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.ComposedSchema;
import io.swagger.v3.oas.models.media.Content;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.parameters.RequestBody;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.ApiResponses;
import io.swagger.v3.oas.models.servers.Server;
import io.swagger.v3.parser.OpenAPIV3Parser;
import io.swagger.v3.parser.core.models.ParseOptions;
import io.swagger.v3.parser.core.models.SwaggerParseResult;

public class SwaggerParserTest2_0 {

	public static void main(String[] args) throws IOException {

		try {
		// 3.0 & 2.0
		ParseOptions parseOptions = new ParseOptions();
		parseOptions.setResolve(true);
		final OpenAPI openAPI = new OpenAPIV3Parser().read("D:\\GAS.yaml", null, parseOptions);
		JSONArray serviceList = new JSONArray();

		JSONObject finalJson = new JSONObject();
		// RequestBody Preparation
		Paths paths = openAPI.getPaths();
		Set<Entry<String, PathItem>> entries = paths.entrySet();
		for (Entry<String, PathItem> entry : entries) {

			// Service Path Item(Endpoint item)
			finalJson.put("PATH", entry.getKey());
			System.out.println("PATH:" + entry.getKey());
			PathItem item = entry.getValue();
			Operation opPost = item.getPost();
			if (opPost != null) {
				System.out.println("POST Operation Not-Null");

				// Request Body formation
				System.out.println("opPost.getRequestBody()" + opPost.getRequestBody());
				RequestBody requestBody = opPost.getRequestBody();
				JSONArray apiRequestJson = new JSONArray();
				JSONObject apiRequestPacket = new JSONObject();

				//Request Packet keys
				String reqPacketXml="";
				JSONObject reqPacketJson=new JSONObject();;
				
				Content reqContent = requestBody.getContent();
				Set<Entry<String, MediaType>> reqEntrySet = reqContent.entrySet();
				
				Iterator<Entry<String, MediaType>> reqMediaTypeIterator = reqEntrySet.iterator();
				while (reqMediaTypeIterator.hasNext()) {
					String requestContentType = null;
					Entry<String, MediaType> meadiaEntry = reqMediaTypeIterator.next();
					requestContentType = meadiaEntry.getKey();
					System.out.println(meadiaEntry.getKey() + "HH");
					System.out.println(meadiaEntry.getValue().getSchema().get$ref() + "HH");

					String[] reqKey = meadiaEntry.getValue().getSchema().get$ref().split("/");
					int reqKeySize = reqKey.length;
					Map<String, Schema> map = openAPI.getComponents().getSchemas();

					String requestPacketKey = reqKey[reqKeySize - 1];
					System.out.println("reqKey[reqKeySize - 1]::::" + requestPacketKey);

					if(requestContentType.equals("application/xml")) {
						reqPacketXml=reqPacketXml+"<"+requestPacketKey+">";
					}else if(requestContentType.equals("application/json")) {
						;
					}
					
					System.out.println(map.keySet() + " KKKKKKKK");
					Schema<?> schema = map.get(reqKey[reqKeySize - 1]);
					System.out.println("schema.getType()::" + schema.getType());

					Map<String, Schema> map2 = schema.getProperties();

					JSONObject requestParametersJson = new JSONObject();
					for (Entry<String, Schema> propEntry : map2.entrySet()) {

//							String key = entry.getKey();
						Schema innerSchema = propEntry.getValue();
						JSONObject propValidaObject = new JSONObject();
						propValidaObject.put("Key", propEntry.getKey());
						propValidaObject.put("Type", innerSchema.getType());
						propValidaObject.put("Title", innerSchema.getTitle());
						propValidaObject.put("Pattern", innerSchema.getPattern());

						
						if (innerSchema.getType().equals("object")) {

							System.out.println(
									"propEntry.getKey()::" + innerSchema.getType() + "::::::" + propEntry.getKey());
							
							JSONObject objectPropJson=getParametersList(innerSchema,requestContentType);
							
							JSONObject parametersListJson=objectPropJson.getJSONObject("parametersListJson");
							propValidaObject.put("Value", parametersListJson);
							JSONObject propJson=null;
							String propXml=null;
							if(requestContentType.equals("application/json")) {
								propJson=objectPropJson.getJSONObject("objectPropJson");
								
								reqPacketJson.put(propEntry.getKey(), propJson);
								
							}else if(requestContentType.equals("application/xml")) {
								propXml=objectPropJson.getString("objectPropXml");
								reqPacketXml=reqPacketXml+"<"+propEntry.getKey()+">"+propXml+"</"+propEntry.getKey()+">";
							}
							
						}else {
							if(requestContentType.equals("application/xml")) {
								reqPacketXml=reqPacketXml+"<"+propEntry.getKey()+">"+innerSchema.getExample()+"</"+propEntry.getKey()+">";
							}else if(requestContentType.equals("application/json")) {
								System.out.println("propEntry.getKey()::"+propEntry.getKey());
								System.out.println("propEntry.getKey()::"+innerSchema.getExample());
								if(innerSchema.getExample()==null) {
									reqPacketJson.put(propEntry.getKey(), "");
								}else {
								reqPacketJson.put(propEntry.getKey(), innerSchema.getExample());
								}
							}
						}
						propValidaObject.put("Example", innerSchema.getExample());
						propValidaObject.put("MinLength", innerSchema.getMinLength());
						propValidaObject.put("MaxLength", innerSchema.getMaxLength());
						propValidaObject.put("Enum", innerSchema.getEnum());

						requestParametersJson.put(propEntry.getKey(), propValidaObject);
						System.out.println(" Inner Value: " + innerSchema + "InnerSchema Type::" + innerSchema.getType()
								+ "Inner Key::" + propEntry.getKey() + "getExample::" + innerSchema.getExample()
								+ "getMinLength::" + innerSchema.getMinLength() + "getMaxLength::"
								+ innerSchema.getMaxLength());
						
					}
					if(requestContentType.equals("application/xml")) {
						reqPacketXml=reqPacketXml+"</"+requestPacketKey+">";
						apiRequestPacket.put("requestPacket", reqPacketXml);
					}else if(requestContentType.equals("application/json")) {
						apiRequestPacket.put("requestPacket", reqPacketJson);
					}

					
					apiRequestPacket.put("requestParameters", requestParametersJson);
					apiRequestPacket.put("contentType", requestContentType);

				}
				apiRequestPacket.put("description", requestBody.getDescription());
				apiRequestJson.put(apiRequestPacket);
				finalJson.put("apiRequest", apiRequestJson);

				System.out.println("Request Body"+finalJson.toString());
				
				// Response Body formation
//				ApiResponses apiResponses = opPost.getResponses();
//				System.out.println(opPost.getResponses());/////////////

				JSONArray apiResponsesJson = new JSONArray();
				JSONObject apiResponsePacket = new JSONObject();
				Map<String, ApiResponse> apiResponseTypes=opPost.getResponses();
				System.out.println(apiResponseTypes.keySet());
				Set<Entry<String, ApiResponse>> apiResEntries = apiResponseTypes.entrySet();
				for (Entry<String, ApiResponse> entry2 : apiResEntries) {

					String repKey = entry2.getKey();
					System.out.println(repKey);

					ApiResponse apiResponse = entry2.getValue();
					
					JSONObject respCode = new JSONObject();
					

					//Response Packet keys
					String respPacketXml="";
					JSONObject respPacketJson=new JSONObject();;
					
					Content content = apiResponse.getContent();
					Set<Entry<String, MediaType>> entrySet = content.entrySet();
					JSONObject respCodeValue = new JSONObject();
					String responseContentType = "";
					Iterator<Entry<String, MediaType>> mediaTypeIterator = entrySet.iterator();
					while (mediaTypeIterator.hasNext()) {
						Entry<String, MediaType> meadiaEntry = mediaTypeIterator.next();
						responseContentType = meadiaEntry.getKey();
						
						System.out.println(meadiaEntry.getKey() + "HH");
//						System.out.println(meadiaEntry.getValue().getSchema().get$ref()+"HH");//////
						
						String[] respKey = meadiaEntry.getValue().getSchema().get$ref().split("/");
						int respKeySize = respKey.length;
						Map<String, Schema> map = openAPI.getComponents().getSchemas();
						
						System.out.println(map);
//						Map<String, ApiResponse> apiResponsesList=openAPI.getComponents().getResponses();
						
						String reponseKey=respKey[respKeySize - 1];
						
						System.out.println("respKey[respKeySize-1]::::" + reponseKey);

						if(responseContentType.equals("application/xml")) {
							respPacketXml=respPacketXml+"<"+reponseKey+">";
						}else if(responseContentType.equals("application/json")) {
							;
						}
						
						
						System.out.println(map.keySet() + " KKKKKKKK");
						Schema<?> schema = map.get(reponseKey);
						
						System.out.println("schema.getType()::" + schema.getType());
						
						System.out.println("schema.getType()::" + schema.get$ref());
						
						System.out.println("schema.getType()::" + schema.getAllOf());
						System.out.println("schema.getType()::" + schema.getAnyOf());
						System.out.println("schema.getType()::" + schema.getOneOf());
					
						
						Map<String, Schema> map2 = null;
						List<Schema> list=null;
						if (schema.getType() == null && schema.getAllOf() != null) {
							System.out.println("schema.getProperties()");
							list = schema.getAllOf();
							System.out.println("getAllOf::" + list);

							JSONObject responseParametersJson = new JSONObject();

							for (Schema propEntry : list) {
////								Map<String, Schema> propEntryMap2 =propEntry.getProperties();
////								
////								for (Entry<String, Schema> propEntry2 : propEntryMap2.entrySet()) {
//
//									String key = propEntry2.getKey();
									
									
								Schema innerSchema = propEntry;
								if (propEntry.get$ref() != null) {
									innerSchema = propEntry;
									
									String[] refRespKey = propEntry.get$ref().split("/");
									int refrespKeySize = refRespKey.length;
									
									String refReponseKey=refRespKey[refrespKeySize - 1];
									
									
//									List<Schema> refList = propEntry.getAllOf();
									
									Map<String, Schema> mapRef = openAPI.getComponents().getSchemas();
									Schema<?> refFinalSchema = mapRef.get(refReponseKey);
									
									Map<String, Schema> finalMap2 = refFinalSchema.getProperties();
									
//									JSONObject responseParametersJson = new JSONObject();
									
									for (Entry<String, Schema> propFinalEntry : finalMap2.entrySet()) {

//										String key = entry.getKey();
									innerSchema = propFinalEntry.getValue();
									JSONObject propValidaObject = new JSONObject();
									propValidaObject.put("Key", propFinalEntry.getKey());
									propValidaObject.put("Type", innerSchema.getType());
									propValidaObject.put("Title", innerSchema.getTitle());
									propValidaObject.put("Pattern", innerSchema.getPattern());

									
									if (innerSchema.getType().equals("object")) {

										System.out.println(
												"propEntry.getKey()::" + innerSchema.getType() + "::::::" + propFinalEntry.getKey());
										
										JSONObject objectPropJson=getParametersList(innerSchema,responseContentType);
										
										JSONObject parametersListJson=objectPropJson.getJSONObject("parametersListJson");
										propValidaObject.put("Value", parametersListJson);
										JSONObject propJson=null;
										String propXml=null;
										if(responseContentType.equals("application/json")) {
											propJson=objectPropJson.getJSONObject("objectPropJson");
											
											respPacketJson.put(propFinalEntry.getKey(), propJson);
											
										}else if(responseContentType.equals("application/xml")) {
											propXml=objectPropJson.getString("objectPropXml");
											respPacketXml=respPacketXml+"<"+propFinalEntry.getKey()+">"+propXml+"</"+propFinalEntry.getKey()+">";
										}
										
									}else {
										if(responseContentType.equals("application/xml")) {
											respPacketXml=respPacketXml+"<"+propFinalEntry.getKey()+">"+innerSchema.getExample()+"</"+propFinalEntry.getKey()+">";
										}else if(responseContentType.equals("application/json")) {
											
											if(innerSchema.getExample()==null) {
												respPacketJson.put(propFinalEntry.getKey(), "");
											}else {
												respPacketJson.put(propFinalEntry.getKey(), innerSchema.getExample());
											}
											
//											respPacketJson.put(propFinalEntry.getKey(), innerSchema.getExample());
										}
									}
									propValidaObject.put("Example", innerSchema.getExample());
									propValidaObject.put("MinLength", innerSchema.getMinLength());
									propValidaObject.put("MaxLength", innerSchema.getMaxLength());

									responseParametersJson.put(propFinalEntry.getKey(), propValidaObject);
									System.out.println(" Inner Value: " + innerSchema + "InnerSchema Type::" + innerSchema.getType()
											+ "Inner Key::" + propFinalEntry.getKey() + "getExample::" + innerSchema.getExample()
											+ "getMinLength::" + innerSchema.getMinLength() + "getMaxLength::"
											+ innerSchema.getMaxLength());
								}
									
								} else {

//								String key = entry.getKey();
									innerSchema = propEntry;
									JSONObject propValidaObject = new JSONObject();
									propValidaObject.put("Key", reponseKey);
									propValidaObject.put("Type", innerSchema.getType());
									propValidaObject.put("Title", innerSchema.getTitle());
									propValidaObject.put("Pattern", innerSchema.getPattern());

									if (innerSchema.getType().equals("object")) {

										System.out.println(
												"propEntry.getKey()::" + innerSchema.getType() + "::::::" + repKey);

										JSONObject objectPropJson = getParametersList(innerSchema, responseContentType);

										JSONObject parametersListJson = objectPropJson
												.getJSONObject("parametersListJson");
										propValidaObject.put("Value", parametersListJson);
										JSONObject propJson = null;
										String propXml = null;
										if (responseContentType.equals("application/json")) {
											if(objectPropJson.has("objectPropJson")) {
												propJson = objectPropJson.getJSONObject("objectPropJson");

												respPacketJson.put(repKey, propJson);
											}
											

										} else if (responseContentType.equals("application/xml")) {
											if(objectPropJson.has("objectPropXml")) {
												propXml = objectPropJson.getString("objectPropXml");
												respPacketXml = respPacketXml + "<" + repKey + ">" + propXml + "</" + repKey
														+ ">";
											}
											
										}

									} else {
										if (responseContentType.equals("application/xml")) {
											respPacketXml = respPacketXml + "<" + repKey + ">"
													+ innerSchema.getExample() + "</" + repKey + ">";
										} else if (responseContentType.equals("application/json")) {
											
											if(innerSchema.getExample()==null) {
												respPacketJson.put(repKey, "");
											}else {
												respPacketJson.put(repKey, innerSchema.getExample());
											}
											respPacketJson.put(repKey, innerSchema.getExample());
										}
									}
									propValidaObject.put("Example", innerSchema.getExample());
									propValidaObject.put("MinLength", innerSchema.getMinLength());
									propValidaObject.put("MaxLength", innerSchema.getMaxLength());

									responseParametersJson.put(repKey, propValidaObject);
									System.out.println(" Inner Value: " + innerSchema + "InnerSchema Type::"
											+ innerSchema.getType() + "Inner Key::" + repKey
											+ "getExample::" + innerSchema.getExample() + "getMinLength::"
											+ innerSchema.getMinLength() + "getMaxLength::"
											+ innerSchema.getMaxLength());
								}
//							}
							}

						} else if (schema.getType() == null && schema.getAnyOf()!=null) {
							System.out.println("schema.getProperties()");
							list = schema.getAnyOf();
							System.out.println("getAllOf::"+list);
							
						
						} else if (schema.getType() == null && schema.getOneOf()!=null) {
							System.out.println("schema.getProperties()");
							list = schema.getOneOf();
							System.out.println("getAllOf::"+list);
							
						}else {

							map2 = schema.getProperties();
							
							JSONObject responseParametersJson = new JSONObject();
							
							for (Entry<String, Schema> propEntry : map2.entrySet()) {

//								String key = entry.getKey();
							Schema innerSchema = propEntry.getValue();
							JSONObject propValidaObject = new JSONObject();
							propValidaObject.put("Key", propEntry.getKey());
							propValidaObject.put("Type", innerSchema.getType());
							propValidaObject.put("Title", innerSchema.getTitle());
							propValidaObject.put("Pattern", innerSchema.getPattern());

							
							if (innerSchema.getType().equals("object")) {

								System.out.println(
										"propEntry.getKey()::" + innerSchema.getType() + "::::::" + propEntry.getKey());
								
								JSONObject objectPropJson=getParametersList(innerSchema,responseContentType);
								
								JSONObject parametersListJson=objectPropJson.getJSONObject("parametersListJson");
								propValidaObject.put("Value", parametersListJson);
								JSONObject propJson=null;
								String propXml=null;
								if(responseContentType.equals("application/json")) {
									
									if(objectPropJson.has("objectPropJson")) {
									propJson=objectPropJson.getJSONObject("objectPropJson");
									
									respPacketJson.put(propEntry.getKey(), propJson);
									}
								}else if(responseContentType.equals("application/xml")) {
									if(objectPropJson.has("objectPropXml")) {
									propXml=objectPropJson.getString("objectPropXml");
									respPacketXml=respPacketXml+"<"+propEntry.getKey()+">"+propXml+"</"+propEntry.getKey()+">";
									}
									}
								
							}else {
								if(responseContentType.equals("application/xml")) {
									respPacketXml=respPacketXml+"<"+propEntry.getKey()+">"+innerSchema.getExample()+"</"+propEntry.getKey()+">";
								}else if(responseContentType.equals("application/json")) {
									
									if(innerSchema.getExample()==null) {
										respPacketJson.put(propEntry.getKey(), "");
									}else {
										respPacketJson.put(propEntry.getKey(), innerSchema.getExample());
									}
//									respPacketJson.put(propEntry.getKey(), innerSchema.getExample());
								}
							}
							propValidaObject.put("Example", innerSchema.getExample());
							propValidaObject.put("MinLength", innerSchema.getMinLength());
							propValidaObject.put("MaxLength", innerSchema.getMaxLength());

							responseParametersJson.put(propEntry.getKey(), propValidaObject);
							System.out.println(" Inner Value: " + innerSchema + "InnerSchema Type::" + innerSchema.getType()
									+ "Inner Key::" + propEntry.getKey() + "getExample::" + innerSchema.getExample()
									+ "getMinLength::" + innerSchema.getMinLength() + "getMaxLength::"
									+ innerSchema.getMaxLength());
						}
						}
						
						
						if(responseContentType.equals("application/xml")) {
							respPacketXml=respPacketXml+"</"+reponseKey+">";
//							apiResponsePacket.put("responsePacket", respPacketXml);
							
						}else if(responseContentType.equals("application/json")) {
//							apiResponsePacket.put("responsePacket", respPacketJson);
							
						}
						
					}
					if(responseContentType.equals("application/xml")) {
						respCodeValue.put("responsePacket", respPacketXml);						
					}else if(responseContentType.equals("application/json")) {
						respCodeValue.put("responsePacket", respPacketJson);
					}else {
						respCodeValue.put("responsePacket", "");
					}
					
					respCodeValue.put("contentType", responseContentType);
//					respCodeValue.put("contentValue",
//							apiResponse.getContent().values().iterator().next().getSchema().getTypes());
					respCodeValue.put("description", apiResponse.getDescription());
					respCode.put(repKey, respCodeValue);
					apiResponsesJson.put(respCode);

				}
				
				
				finalJson.put("apiResponses", apiResponsesJson);
			

//				System.out.println(opPost.getParameters());
				finalJson.put("PARAMETERS", opPost.getParameters());
				System.out.println(opPost.getTags());
				finalJson.put("TAG", opPost.getTags());
			} else {
				System.out.println("POST Operation Null");
			}
			Operation opGet = item.getGet();
			if (opGet != null) {
				System.out.println("GET Operation Not-Null");
			} else {
				System.out.println("GET Operation Null");
			}

//			System.out.println(item.getPost().getRequestBody().toString());
			System.out.println("_________________________________________");
			Set<Entry<String, MediaType>> meadiaEntries = item.getPost().getRequestBody().getContent().entrySet();
			Iterator<Entry<String, MediaType>> iterator = meadiaEntries.iterator();
			Entry<String, MediaType> meadiaEntry = iterator.next();

			System.out.println(meadiaEntry.getKey() + "HH");
			System.out.println(openAPI.getPaths().keySet());

			Map<String, Schema> map = openAPI.getComponents().getSchemas();

			System.out.println(map.keySet() + " JJJ");


			List<Server> serverList = openAPI.getServers();
			for (Iterator serverIterator = serverList.iterator(); serverIterator.hasNext();) {

				Server server = (Server) serverIterator.next();
				// URL part
				System.out.println(server.getUrl());
				finalJson.put("URL", server.getUrl());
				// Title & API Description
				System.out.println(openAPI.getInfo().getTitle());
				finalJson.put("API_NAME", openAPI.getInfo().getTitle());
				System.out.println(openAPI.getInfo().getDescription());
				finalJson.put("API_DESCRIPTION", openAPI.getInfo().getDescription());

				serviceList.put(finalJson);
			}

		}

		System.out.println(serviceList);
		
	}catch(Exception e) {
			System.out.println("Invalid Specification document");
		}
	}

	public static JSONObject getParametersList(Schema schema,String requestContentType) {

		Map<String, Schema> map2 = schema.getProperties();
		JSONObject finalJSon=new JSONObject();
		
		
		JSONObject requestParametersJson = new JSONObject();
		
		
		//Request Packet keys
		String reqPacketXml="";
		JSONObject reqPacketJson=new JSONObject();;
		for (Entry<String, Schema> propEntry : map2.entrySet()) {

//				String key = entry.getKey();
			Schema innerSchema = propEntry.getValue();
			JSONObject propValidaObject = new JSONObject();
			propValidaObject.put("Key", propEntry.getKey());
			propValidaObject.put("Type", innerSchema.getType());
			propValidaObject.put("Title", innerSchema.getTitle());
			propValidaObject.put("Pattern", innerSchema.getPattern());
//			if (innerSchema.getType().equals("object")) {
//
//				System.out.println("propEntry.getKey()::" + innerSchema.getType());
//				propValidaObject.put("Value", getParametersList(innerSchema,requestContentType));
//			}
			
			if (innerSchema.getType().equals("object")) {

				System.out.println(
						"propEntry.getKey()::" + innerSchema.getType() + "::::::" + propEntry.getKey());
				
				JSONObject objectPropJson=getParametersList(innerSchema,requestContentType);
				
				//validation Parameter Object add
				JSONObject parametersListJson=objectPropJson.getJSONObject("parametersListJson");
				propValidaObject.put("Value", parametersListJson);
				
				//Request Packet keys data addtion
				JSONObject propJson=null;
				String propXml=null;
				if(requestContentType.equals("application/json")) {
					propJson=objectPropJson.getJSONObject("objectPropJson");
					
					reqPacketJson.put(propEntry.getKey(), propJson);
					
				}else if(requestContentType.equals("application/xml")) {
					propXml=objectPropJson.getString("objectPropXml");
					reqPacketXml=reqPacketXml+"<"+propEntry.getKey()+">"+propXml+"</"+propEntry.getKey()+">";
				}
				
			}else {
				if(requestContentType.equals("application/xml")) {
					reqPacketXml=reqPacketXml+"<"+propEntry.getKey()+">"+innerSchema.getExample()+"</"+propEntry.getKey()+">";
				}else if(requestContentType.equals("application/json")) {
					if(innerSchema.getExample()==null) {
						reqPacketJson.put(propEntry.getKey(), "");
					}else {
					reqPacketJson.put(propEntry.getKey(), innerSchema.getExample());
					}
//					reqPacketJson.put(propEntry.getKey(), innerSchema.getExample());
				}
			}

			propValidaObject.put("Example", innerSchema.getExample());
			propValidaObject.put("MinLength", innerSchema.getMinLength());
			propValidaObject.put("MaxLength", innerSchema.getMaxLength());
			propValidaObject.put("Enum", innerSchema.getEnum());

			requestParametersJson.put(propEntry.getKey(), propValidaObject);
			System.out.println(" Inner Value: " + innerSchema + "InnerSchema Type::" + innerSchema.getType()
					+ "Inner Key::" + propEntry.getKey() + "getExample::" + innerSchema.getExample() + "getMinLength::"
					+ innerSchema.getMinLength() + "getMaxLength::" + innerSchema.getMaxLength());
		}
		
		if(requestContentType.equals("application/json")) {
			
			finalJSon.put("parametersListJson", reqPacketJson);
			
		}else if(requestContentType.equals("application/xml")) {
			
			finalJSon.put("objectPropXml", reqPacketXml);
			
		}
		finalJSon.put("parametersListJson", requestParametersJson);
		
		return finalJSon;

	}

}

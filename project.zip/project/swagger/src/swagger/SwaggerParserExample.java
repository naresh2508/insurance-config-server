package swagger;

import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import io.swagger.models.ArrayModel;
import io.swagger.models.HttpMethod;
import io.swagger.models.Model;
import io.swagger.models.Operation;
import io.swagger.models.Path;
import io.swagger.models.Response;
import io.swagger.models.Swagger;
import io.swagger.models.parameters.BodyParameter;
import io.swagger.models.parameters.Parameter;
import io.swagger.models.parameters.PathParameter;
import io.swagger.models.properties.ArrayProperty;
import io.swagger.models.properties.Property;
import io.swagger.models.properties.RefProperty;
import io.swagger.models.refs.RefFormat;
import io.swagger.parser.SwaggerParser;

public class SwaggerParserExample {
	static JSONObject apiJson=new JSONObject();
	static JSONObject propJson=new JSONObject();
	static String request="";
	public static void main(String[] args) {
		Swagger swagger = new SwaggerParser().read("D:\\eCollection YAML.yaml");
		
		
		
			
			apiJson.put("consumes", swagger.getConsumes());
			apiJson.put("produces", swagger.getProduces());
			
			
		
//		System.out.println("Description: " + swagger.getInfo().getDescription());
		for(Map.Entry<String, Path> entry : swagger.getPaths().entrySet()) {
			System.out.println(entry.getKey());
			getOperationDetails(swagger, entry.getValue().getOperationMap());
		}
		apiJson.put("request", propJson);
		
		System.out.println(apiJson.toString());
	}

	private static void getOperationDetails(Swagger swagger, Map<HttpMethod, Operation> operationMap) {
		for(Map.Entry<HttpMethod, Operation> op : operationMap.entrySet()) {
			System.out.println("____________________________________________________\n");
			System.out.println(op.getKey() + " - " + op.getValue().getOperationId());
			System.out.println("Parameters ->");
			for(Parameter p : op.getValue().getParameters()) {
				if(p instanceof BodyParameter) {
					getBodyDetails(swagger, (BodyParameter) p);
				} else {
					String paramType = p.getClass().getSimpleName();
					if(p instanceof PathParameter) {
						paramType = "path";
					}
					System.out.println(p.getName() + " : " + paramType);
				}
			}
			getResponseDetails(swagger, op.getValue().getResponses());
		}
	}

	private static void getBodyDetails(Swagger swagger, BodyParameter p) {
		System.out.println("BODY: ");

		RefProperty rp = new RefProperty(p.getSchema().getReference());
		getReferenceDetails(swagger, rp);
	}

	private static void getResponseDetails(Swagger swagger, Map<String, Response> responseMap) {
		System.out.println("Responses:");
		System.out.println("-----------");
		for(Map.Entry<String, Response> response : responseMap.entrySet()) {
			System.out.println(response.getKey() + ": " + response.getValue().getDescription());

			if(response.getValue().getSchema() instanceof RefProperty) {
				RefProperty rp = (RefProperty)response.getValue().getSchema();
				getReferenceDetails(swagger, rp);
			}

			if(response.getValue().getSchema() instanceof ArrayProperty) {
				ArrayProperty ap = (ArrayProperty)response.getValue().getSchema();
				if(ap.getItems() instanceof RefProperty) {
					RefProperty rp = (RefProperty)ap.getItems();
					System.out.println(rp.getSimpleRef() + "[]");
					getReferenceDetails(swagger, rp);
				}
			}
		}
	}

	private static void getReferenceDetails(Swagger swagger, RefProperty rp) {
		boolean isArrayModel=false;
		
		if(rp.getRefFormat().equals(RefFormat.INTERNAL) &&
				swagger.getDefinitions().containsKey(rp.getSimpleRef())) {
			Model m = swagger.getDefinitions().get(rp.getSimpleRef());

			if(m instanceof ArrayModel) {
				ArrayModel arrayModel = (ArrayModel)m;
				isArrayModel=true;
				System.out.println(rp.getSimpleRef() + "[]");
				if(arrayModel.getItems() instanceof RefProperty) {
					RefProperty arrayModelRefProp = (RefProperty)arrayModel.getItems();
					getReferenceDetails(swagger, arrayModelRefProp);
					
				}
			}
			
			if(m.getProperties() != null) {
				
				for (Map.Entry<String, Property> propertyEntry : m.getProperties().entrySet()) {
					JSONObject propValidation=new JSONObject();
					System.out.println("  " + propertyEntry.getKey() + " : " + propertyEntry.getValue().getType()+","+propertyEntry.getValue().getExample());
//					JSONObject propValidation=new JSONObject();
					propValidation.put("Type", propertyEntry.getValue().getType());
					propValidation.put("Example", propertyEntry.getValue().getExample());
					propValidation.put("Required", propertyEntry.getValue().getRequired());
					propValidation.put("AllowEmptyValue", propertyEntry.getValue().getAllowEmptyValue());
					propValidation.put("Description", propertyEntry.getValue().getDescription());
					propValidation.put("Position()", propertyEntry.getValue().getPosition());

					
					if(isArrayModel) {
						String arrayModelName=rp.get$ref();
					propJson.put(arrayModelName,propValidation);
					isArrayModel=false;
					}else {
					propJson.put(propertyEntry.getKey(),propValidation);
					}
				}
				
			}
		}
	}
}


package swagger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import org.json.JSONArray;
import org.json.JSONObject;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Paths;
import io.swagger.v3.parser.OpenAPIV3Parser;
import io.swagger.v3.parser.core.models.ParseOptions;

public class SWTest {

	public static void main(String[] args) {

		
//		ParseOptions parseOptions = new ParseOptions();
//		parseOptions.setResolve(true); 
//		final OpenAPI openAPI = new OpenAPIV3Parser().read("D:\\Sample_YAML.yaml", null, parseOptions);
//		Paths paths=openAPI.getPaths();
		
		String txData="";
		
		try (BufferedReader br = new BufferedReader(new FileReader("D:\\API_UTILITY_TRANSACTIONS.txt"))) {
            StringBuilder fileContentBuilder = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                fileContentBuilder.append(line).append("\n");
            }

            // Remove the trailing newline character
            txData = fileContentBuilder.toString().trim();

            // Print or use the String as needed
            System.out.println(txData);
        } catch (Exception e) {
            e.printStackTrace();
        }
		
		
		
		
		
		
		
		
		JSONObject txDataJson = new JSONObject(txData);
		String finalQuery = "";
		for (String tableName : txDataJson.keySet()) {
//			System.out.println("tableName::"+tableName);
			JSONArray idList = txDataJson.getJSONArray(tableName);
			String deleteQuery = "DELETE " + tableName + " WHERE ";
			int length = idList.length();
			if (length < 1000) {
				// Single Batch
				String ids = "";
				String strIds = "";

				for (int j = 0; j < length; j++) {
					// Get the integer at the current index
					int currentInt = idList.getInt(j);

					if (ids == "") {
						ids = ids + currentInt;
					} else {
						ids = ids + "," + currentInt;
					}

					if (strIds == "") {
						strIds = "'" + currentInt + "'";
					} else {
						strIds = strIds + "," + "'" + currentInt + "'";
					}
				}

				switch (tableName) {
				case "API_DETAIL":
					finalQuery = deleteQuery + "API_ID IN (" + ids + ")";
					System.out.println("finalQuery::" + finalQuery);
//				recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
					break;
				case "ADD_PARAMETERS_TABLE":
					finalQuery = deleteQuery + "API_ID IN (" + ids + ")";
					System.out.println("finalQuery::" + finalQuery);
//				recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
					break;
				case "API_REQ_PARAMETER":
					finalQuery = deleteQuery + "REQ_ID IN (" + ids + ")";
					System.out.println("finalQuery::" + finalQuery);
//				recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
					break;
				case "API_RES_PARAMETER":
					finalQuery = deleteQuery + "RESP_ID IN (" + ids + ")";
					System.out.println("finalQuery::" + finalQuery);
//				recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
					break;
				case "API_SAMPLE_PACKET":
					finalQuery = deleteQuery + "PACKET_ID IN (" + strIds + ")";
					System.out.println("finalQuery::" + finalQuery);
//				recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
					break;

				case "API_SAMPLE_RESP_TBL":
					finalQuery = deleteQuery + "API_ID IN (" + ids + ")";
					System.out.println("finalQuery::" + finalQuery);
//				recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
					break;

				case "PORTAL_MENU_TREE":
					finalQuery = deleteQuery + "ID IN (" + ids + ")";
					System.out.println("finalQuery::" + finalQuery);
//				recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
					break;
				default:
					// break;
				}

			} else {
				// Multiple Batch
				int batchCount = length / 1000;
				int remainingCount = length % 1000;

				if (remainingCount > 0) {
					batchCount++;
				}
				System.out.println(batchCount);
				int batchSize = 0;
				int startBatchSize = 0;
				for (int i = 1; i <= batchCount; i++) {
					batchSize = startBatchSize + 1000;
					String ids = "";
					String strIds = "";
					if (i >= batchCount) {
						batchSize = length;
					}

					for (int j = startBatchSize; j < batchSize; j++) {
						// Get the integer at the current index
						int currentInt = idList.getInt(j);

						if (ids == "") {
							ids = ids + currentInt;
						} else {
							ids = ids + "," + currentInt;
						}

						if (strIds == "") {
							strIds = "'" + currentInt + "'";
						} else {
							strIds = strIds + "," + "'" + currentInt + "'";
						}
					}

					switch (tableName) {
					case "API_DETAIL":
						finalQuery = deleteQuery + "API_ID IN (" + ids + ")";
						System.out.println("finalQuery::" + finalQuery);
//					recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
						break;
					case "ADD_PARAMETERS_TABLE":
						finalQuery = deleteQuery + "API_ID IN (" + ids + ")";
						System.out.println("finalQuery::" + finalQuery);
//					recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
						break;
					case "API_REQ_PARAMETER":
						finalQuery = deleteQuery + "REQ_ID IN (" + ids + ")";
						System.out.println("finalQuery::" + finalQuery);
//					recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
						break;
					case "API_RES_PARAMETER":
						finalQuery = deleteQuery + "RESP_ID IN (" + ids + ")";
						System.out.println("finalQuery::" + finalQuery);
//					recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
						break;
					case "API_SAMPLE_PACKET":
						finalQuery = deleteQuery + "PACKET_ID IN (" + strIds + ")";
						System.out.println("finalQuery::" + finalQuery);
//					recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
						break;

					case "API_SAMPLE_RESP_TBL":
						finalQuery = deleteQuery + "API_ID IN (" + ids + ")";
						System.out.println("finalQuery::" + finalQuery);
//					recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
						break;

					case "PORTAL_MENU_TREE":
						finalQuery = deleteQuery + "ID IN (" + ids + ")";
						System.out.println("finalQuery::" + finalQuery);
//					recods=recods+inboundOutboundDao.excecuteQuery(finalQuery);
						break;
					default:
						// break;
					}
					startBatchSize = startBatchSize + 1000;

				}

			}
		}

	}

}

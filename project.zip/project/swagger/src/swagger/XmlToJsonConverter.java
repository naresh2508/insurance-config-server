package swagger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import java.io.StringReader;
import java.util.Iterator;
import java.util.Set;

public class XmlToJsonConverter {

    public static void main(String[] args) {
        String xmlString = "<request><api_version>1.2.0</api_version><request_id>793049843</request_id><request_datetime>2023-10-05T15:44:16.445+05:30</request_datetime><parent_request_id>30F14673-BF37-4C55-89E3-AD7ED78BFB14</parent_request_id><parent_request_datetime>2023-10-17T10:06:08.052</parent_request_datetime><channel_id>ICore</channel_id><sender_system_id>ICore</sender_system_id><sender_system_user_id>raman.kumar@icicibank.com</sender_system_user_id><sender_system_user_id_type>email</sender_system_user_id_type><request_priority>1</request_priority><resent_indicator>false</resent_indicator><original_request_id>793049843</original_request_id><original_request_datetime>2023-10-17T10:06:08.052</original_request_datetime><original_channel_id>ICore</original_channel_id><original_sender_system_id>ICore</original_sender_system_id><original_sender_system_user_id>raman.kumar@icicibank.com</original_sender_system_user_id><original_sender_system_user_id_type>email</original_sender_system_user_id_type><original_request_priority>1</original_request_priority><original_requires_message_delivery_report_indicator>true</original_requires_message_delivery_report_indicator><test_indicator>false</test_indicator><product_type>GAS</product_type><message_type>send-alert</message_type><operation_name>send-alert</operation_name><gas><dept>ICICIBANK</dept><pan>abcd2323b</pan><message><tran_id>S31872280</tran_id><tran_date>17-10-2023</tran_date><dtd_vfd_date>17-10-2023 10:05:46</dtd_vfd_date><value_date>17-10-2023</value_date><part_tran_srl_num>1</part_tran_srl_num><tran_type>T</tran_type><tran_sub_type>CI</tran_sub_type><tran_mode>IMPS</tran_mode><drcr_ind>D</drcr_ind><tran_amount>25000</tran_amount><tran_crncy_code>INR</tran_crncy_code><foracid>100805002898</foracid><acct_name>NAVI FINSERV LIMITED</acct_name><acct_sol_id>1008</acct_sol_id><acct_crncy_code>INR</acct_crncy_code><rate>1</rate><init_sol_id>1008</init_sol_id><init_br_name>Gachibowli</init_br_name><balance>439139077</balance><tran_particular>MMT/IMPS/329010300462/Fund transfer from Navi 2310</tran_particular><tran_particular2>17IC339/BARB0NAWALG</tran_particular2><tran_rmks>329010300462//9012001008100009</tran_rmks><uad_module_id>null</uad_module_id><uad_module_key><utr_ref_num>329010300462</utr_ref_num><party_account_num>1234567890</party_account_num><ifsc_code>BARB0NAWALG</ifsc_code><party_code></party_code><sender_receiver_info></sender_receiver_info><party_name>ABCD</party_name><party_ref_num>123456789</party_ref_num></uad_module_key><inst_num>null</inst_num><inst_type></inst_type><isureapay_ref_num>null</isureapay_ref_num></message></gas></request>";

        xmlString=xmlString.replaceAll("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
        try {  
        	JSONObject json = XML.toJSONObject(xmlString);   
//        	        String jsonString = json.toString(4);  
        	        System.out.println(json);  
        	        System.out.println(json.keySet());
        	        Set<String> keys=json.keySet();
        	        JSONObject payloadList=new JSONObject();
        	        
        	        int i=0;
        	        Iterator<String> iterator = keys.iterator();
        	        while (iterator.hasNext()) {
        	        	++i;
        	            String element = iterator.next();
        	        	
        	        	JSONObject obj=json.getJSONObject(element);
        	            System.out.println(obj.getClass().getSimpleName());
        	            JSONObject object=null;
        	            if(obj.getClass().getSimpleName().equals("JSONObject")) {
        	            	 object=new JSONObject();
        	            	 
        	            	 int j=0;
        	            	 Set<String> set=obj.keySet();
        	            	 Iterator<String> iterator1 = set.iterator();
        	        	        while (iterator1.hasNext()) {
        	        	        	++j;
        	        	            String key = iterator1.next();
        	        	            if(obj.get(key).getClass().getSimpleName().equals("JSONObject")) {
        	        	            	JSONObject object1=getJSONObjectPayload(obj.getJSONObject(key),object);
        	        	            	object=mergeJSONObjects(object, object1);
        	        	            }else {
        	        	            	Object keyValueClassType= obj.get(key);
        	        	            	if(keyValueClassType instanceof Boolean) {
        	        	            		object.put(key, obj.getBoolean(key));
        	        	            	}else if(keyValueClassType instanceof String) {
        	        	            		object.put(key, obj.getString(key));
        	        	            	}else if(keyValueClassType instanceof Integer) {
        	        	            		object.put(key, obj.getInt(key));
        	        	            	}else if(keyValueClassType instanceof Float) {
        	        	            		object.put(key, obj.getFloat(key));
        	        	            	}else if(keyValueClassType instanceof Long) {
        	        	            		object.put(key, obj.getLong(key));
        	        	            	}else if(keyValueClassType instanceof Double) {
        	        	            		object.put(key, obj.getDouble(key));
        	        	            	}else if(keyValueClassType instanceof Number) {
        	        	            		object.put(key, obj.getNumber(key));
        	        	            	}
        	        	            	
        	        	            }
        	            	 
        	            	 
        	            	 
        	        	        }
        	            }
//        	            System.out.println(obj.keySet());
        	           
        	            payloadList.put("PAYLOAD"+i, object);
        	        }
        	        System.out.println(payloadList.toString());
        	  
        	}catch (JSONException e) {  
        	// TODO: handle exception  
        	System.out.println(e.toString());  
        	}  
    }
    
    
    public static JSONObject getJSONObjectPayload(JSONObject obj,JSONObject newJson) {
    	
    	
    	 int j=0;
    	 Set<String> set=obj.keySet();
    	 Iterator<String> iterator1 = set.iterator();
	        while (iterator1.hasNext()) {
	        	++j;
	            String key = iterator1.next();
	            if(obj.get(key).getClass().getSimpleName().equals("JSONObject")) {
	            	JSONObject object1=getJSONObjectPayload(obj.getJSONObject(key),newJson);
	            	newJson=mergeJSONObjects(object1, newJson);
	            }else {
	            	Object keyValueClassType= obj.get(key);
	            	if(keyValueClassType instanceof Boolean) {
	            		newJson.put(key, obj.getBoolean(key));
	            	}else if(keyValueClassType instanceof String) {
	            		newJson.put(key, obj.getString(key));
	            	}else if(keyValueClassType instanceof Integer) {
	            		newJson.put(key, obj.getInt(key));
	            	}else if(keyValueClassType instanceof Float) {
	            		newJson.put(key, obj.getFloat(key));
	            	}else if(keyValueClassType instanceof Long) {
	            		newJson.put(key, obj.getLong(key));
	            	}else if(keyValueClassType instanceof Double) {
	            		newJson.put(key, obj.getDouble(key));
	            	}else if(keyValueClassType instanceof Number) {
	            		newJson.put(key, obj.getNumber(key));
	            	}
	            	
	            }
    	 
    	 
    	 
	        }
    	
    	
    	
		return newJson;
    }
    
    
    public static JSONObject mergeJSONObjects(JSONObject json1, JSONObject json2) throws JSONException {
        JSONObject merged = new JSONObject(json1.toString()); // Clone json1

        for (String key : json2.keySet()) {
            merged.put(key, json2.get(key));
        }

        return merged;
    }
}
